import { createClient } from "@supabase/supabase-js";

export function supabaseServer() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY ?? process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
  // Server: si tienes Service Role mejor usarlo SOLO en server actions con filtros por tenant.
  return createClient(supabaseUrl, supabaseKey, { auth: { persistSession: false } });
}
