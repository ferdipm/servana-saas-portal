"use server";
import { supabaseServer } from "@/lib/supabaseServer";

export type Reservation = {
  id: string;
  phone: string | null;
  name: string;
  source: string | null;
  created_at: string;
  status: string;
  business_id: string | null;
  tz: string | null;
  chat_id: string | null;
  locator: string | null;
  party_size: number | null;
  datetime_utc: string;
  notes: string | null;
  tenant_id: string | null;
  reminder_sent: boolean | null;
};

export async function getReservations(opts: {
  businessId: string;
  q?: string;
  status?: string;
  from?: string;
  to?: string;
  limit?: number;
  cursorCreatedAt?: string | null;
}) {
  const { businessId, q, status, from, to, limit = 50 } = opts;
  const supabase = supabaseServer();

  let query = supabase
    .from("reservations")
    .select("*")
    .eq("business_id", businessId)
    .order("datetime_utc", { ascending: false })
    .limit(limit);

  if (status && status !== "all") query = query.eq("status", status);
  if (from) query = query.gte("datetime_utc", from);
  if (to) query = query.lte("datetime_utc", to);
  if (q && q.trim()) {
    query = query.or(
      `name.ilike.%${q}%,phone.ilike.%${q}%,notes.ilike.%${q}%,locator.ilike.%${q}%`
    );
  }

  const { data, error } = await query;
  if (error) throw new Error(error.message);
  const rows = (data as Reservation[]) ?? [];
  const nextCursor =
    rows.length === limit ? rows[rows.length - 1]?.created_at ?? null : null;

  return { data: rows, nextCursor };
}

export async function getReservationsSummary({ businessId }: { businessId: string }) {
  const supabase = supabaseServer();
  const now = new Date();

  // Tomamos como referencia días en UTC para simplificar (MVP).
  const startOfToday = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  const startOfTomorrow = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1));
  const startOfDayAfterTomorrow = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 2));

  // Próximo lunes (inicio de la siguiente semana, usado como final de semana actual)
  const todayWeekday = startOfToday.getUTCDay(); // 0=domingo, 1=lunes, ...
  const daysUntilNextMonday = (8 - todayWeekday) % 7 || 7; // al menos 7 días
  const startOfNextMonday = new Date(
    Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + daysUntilNextMonday)
  );

  // Límites de mes
  const startOfMonth = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  const startOfNextMonth = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));

  // 1) Hoy
  const { count: today, error: todayError } = await supabase
    .from("reservations")
    .select("id", { count: "exact", head: true })
    .eq("business_id", businessId)
    .gte("datetime_utc", startOfToday.toISOString())
    .lt("datetime_utc", startOfTomorrow.toISOString());

  // 2) Mañana
  const { count: tomorrow, error: tomorrowError } = await supabase
    .from("reservations")
    .select("id", { count: "exact", head: true })
    .eq("business_id", businessId)
    .gte("datetime_utc", startOfTomorrow.toISOString())
    .lt("datetime_utc", startOfDayAfterTomorrow.toISOString());

  // 3) Resto semana (desde pasado mañana hasta final de semana actual)
  const { count: weekRest, error: weekRestError } = await supabase
    .from("reservations")
    .select("id", { count: "exact", head: true })
    .eq("business_id", businessId)
    .gte("datetime_utc", startOfDayAfterTomorrow.toISOString())
    .lt("datetime_utc", startOfNextMonday.toISOString());

  // 4) Resto mes (desde pasado mañana hasta final de mes en curso)
  const { count: monthRest, error: monthRestError } = await supabase
    .from("reservations")
    .select("id", { count: "exact", head: true })
    .eq("business_id", businessId)
    .gte("datetime_utc", startOfDayAfterTomorrow.toISOString())
    .lt("datetime_utc", startOfNextMonth.toISOString());

  if (todayError || tomorrowError || weekRestError || monthRestError) {
    console.error("Error obteniendo summary", { todayError, tomorrowError, weekRestError, monthRestError });
  }

  return {
    today: today ?? 0,
    tomorrow: tomorrow ?? 0,
    weekRest: weekRest ?? 0,
    monthRest: monthRest ?? 0,
  };
}

