import { Suspense } from "react";
import { ReservationsView } from "./reservations-view";
import DashboardShell from "./dashboard-shell";
import { SummaryCards } from "./summary-cards";


export default function Page() {
  const businessId = process.env.NEXT_PUBLIC_DEMO_BUSINESS_ID ?? "";

  return (
    <DashboardShell>
      <div className="space-y-6">
              <Suspense
                fallback={
                  <div className="grid gap-4 md:grid-cols-3 mb-6">
                    <div className="h-24 rounded-2xl bg-zinc-100 dark:bg-zinc-900/60 animate-pulse" />
                    <div className="h-24 rounded-2xl bg-zinc-100 dark:bg-zinc-900/60 animate-pulse" />
                    <div className="h-24 rounded-2xl bg-zinc-100 dark:bg-zinc-900/60 animate-pulse" />
                  </div>
                }
              >
                <SummaryCards businessId={businessId} />
              </Suspense>

              <section className="rounded-2xl border border-zinc-200/50 dark:border-zinc-700/50 bg-white/70 dark:bg-[#121317]/90 overflow-hidden">
                <div className="p-2 md:p-4">
                  <Suspense fallback={<div className="h-[420px] rounded-xl border bg-white/60 dark:bg-zinc-900/60" />}>
                    <ReservationsView businessId={businessId} defaultTz="Europe/Zurich" />
                  </Suspense>
                </div>
              </section>
        </div>
    </DashboardShell>
  );
}
