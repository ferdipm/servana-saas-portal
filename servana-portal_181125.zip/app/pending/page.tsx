// app/pending/page.tsx
import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabaseServer";
import { getCurrentTenantId } from "@/lib/getCurrentTenant";
import DashboardShell from "../dashboard-shell";
import { ReservationsView } from "../reservations-view";

export default async function PendingPage() {
  const supabase = await supabaseServer();

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  // 🔐 Mismo patrón que en app/page.tsx
  if (error || !user) {
    redirect(`/login?redirectTo=/pending`);
  }

  const { tenantId } = await getCurrentTenantId();
  const defaultTz = "Europe/Zurich";

  return (
    <DashboardShell>
      <div className="p-6 space-y-6">
        <header className="mb-2">
          <h1 className="text-xl font-semibold tracking-tight">
            Reservas pendientes
          </h1>
          <p className="text-sm text-zinc-500">
            Solicitudes que requieren revisión y confirmación manual.
          </p>
        </header>

        <section className="mt-4">
          <ReservationsView
            tenantId={tenantId}
            defaultTz={defaultTz}
            initialStatus="pending"  // 👈 Aquí está la magia
          />
        </section>
      </div>
    </DashboardShell>
  );
}
// app/pending/page.tsx
import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabaseServer";
import { getTenantAndRestaurants } from "@/lib/getTenantAndRestaurants";
import DashboardShell from "../dashboard-shell";
import { ReservationsView } from "../reservations-view";

type PendingPageProps = {
  searchParams?: {
    restaurantId?: string;
  };
};

export default async function PendingPage({ searchParams }: PendingPageProps) {
  const supabase = await supabaseServer();

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  // Mismo patrón que en app/page.tsx: proteger por auth
  if (error || !user) {
    redirect(`/login?redirectTo=/pending`);
  }

  const requestedRestaurantId = searchParams?.restaurantId;

  const {
    tenantId,
    accessibleRestaurants,
    currentRestaurantId,
    canSwitch,
  } = await getTenantAndRestaurants(requestedRestaurantId);

  const defaultTz = "Europe/Zurich";

  return (
    <DashboardShell
      userEmail={user.email}
      restaurants={accessibleRestaurants}
      currentRestaurantId={currentRestaurantId}
      canSwitch={canSwitch}
    >
      <div className="p-6 space-y-6">
        <header className="mb-2">
          <h1 className="text-xl font-semibold tracking-tight">
            Reservas pendientes
          </h1>
          <p className="text-sm text-zinc-500">
            Solicitudes que requieren revisión y confirmación manual.
          </p>
        </header>

        <section className="mt-4">
          <ReservationsView
            tenantId={tenantId}
            defaultTz={defaultTz}
            initialStatus="pending"
          />
        </section>
      </div>
    </DashboardShell>
  );
}