export const dynamic = "force-dynamic";

import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabaseServer";
import { getTenantAndRestaurants } from "@/lib/getTenantAndRestaurants";
import DashboardShell from "./dashboard-shell";
import { SummaryCards } from "./summary-cards";
import { ReservationsView } from "./reservations-view";

type PageProps = {
  searchParams?: Promise<{
    restaurantId?: string;
  }>;
};

export default async function Page({ searchParams }: PageProps) {
  const supabase = await supabaseServer();

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error || !user) {
    redirect(`/login?redirectTo=/`);
  }

  const params = await searchParams;
  const requestedRestaurantId = params?.restaurantId;

  const {
    tenantId,
    accessibleRestaurants,
    currentRestaurantId,
    canSwitch,
  } = await getTenantAndRestaurants(requestedRestaurantId);

  const defaultTz = "Europe/Zurich";

  return (
    <DashboardShell
      userEmail={user.email}
      restaurants={accessibleRestaurants}
      currentRestaurantId={currentRestaurantId}
      canSwitch={canSwitch}
    >
      <div className="p-6 space-y-6">
        <SummaryCards tenantId={tenantId} />
        <ReservationsView
          key={currentRestaurantId}
          tenantId={tenantId}
          restaurantId={currentRestaurantId}
          defaultTz={defaultTz}
        />
      </div>
    </DashboardShell>
  );
}