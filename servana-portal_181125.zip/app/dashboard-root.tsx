"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";

type Restaurant = {
  id: string;
  name: string;
  slug?: string | null;
};

type RestaurantSwitcherProps = {
  restaurants?: Restaurant[];
  currentRestaurantId?: string;
  canSwitch?: boolean;
};

export function RestaurantSwitcher({
  restaurants = [],
  currentRestaurantId,
  canSwitch = false,
}: RestaurantSwitcherProps) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  if (!restaurants.length || !currentRestaurantId) {
    return null;
  }

  const current =
    restaurants.find((r) => r.id === currentRestaurantId) ?? restaurants[0];

  // Caso: solo un restaurante o el usuario no puede cambiar → solo texto
  if (!canSwitch || restaurants.length <= 1) {
    return (
      <div className="text-sm text-zinc-400">
        Restaurante:{" "}
        <span className="font-medium text-zinc-100">{current.name}</span>
      </div>
    );
  }

  const handleChange = (newId: string) => {
    const params = new URLSearchParams(searchParams?.toString());

    if (newId) {
      params.set("restaurantId", newId);
    } else {
      params.delete("restaurantId");
    }

    const qs = params.toString();
    const href = qs ? `${pathname}?${qs}` : pathname;

    router.push(href);
  };

  return (
    <div className="flex items-center gap-2">
      <span className="text-sm text-zinc-400">Restaurante:</span>
      <select
        className="border border-zinc-700/70 rounded-md px-2 py-1 bg-[#1c1e24] text-sm text-zinc-100"
        value={current.id}
        onChange={(e) => handleChange(e.target.value)}
      >
        {restaurants.map((r) => (
          <option key={r.id} value={r.id}>
            {r.name}
          </option>
        ))}
      </select>
    </div>
  );
}