// app/settings/page.tsx
import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabaseServer";
import { getTenantAndRestaurants } from "@/lib/getTenantAndRestaurants";
import DashboardShell from "../dashboard-shell";

type SettingsPageProps = {
  searchParams?: Promise<{
    restaurantId?: string;
  }>;
};

export default async function SettingsPage({ searchParams }: SettingsPageProps) {
  const supabase = await supabaseServer();

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error || !user) {
    redirect("/login?redirectTo=/settings");
  }

  const params = await searchParams;
  const requestedRestaurantId = params?.restaurantId;

  const {
    tenantId,
    accessibleRestaurants,
    currentRestaurantId,
    canSwitch,
    role,
  } = await getTenantAndRestaurants(requestedRestaurantId);

  const isOwnerLike =
    role === "owner" || role === "admin" || role === "group_manager";

  const onboardingUrl = `https://servana-ia-production.up.railway.app/onboarding.html?tenantId=${tenantId}`;

  return (
    <DashboardShell
      userEmail={user.email}
      restaurants={accessibleRestaurants}
      currentRestaurantId={currentRestaurantId}
      canSwitch={canSwitch}
    >
      <div className="p-6 space-y-6">
        <div className="max-w-xl rounded-2xl border border-zinc-200/60 dark:border-zinc-800/60 bg-white/80 dark:bg-[#121317]/95 px-5 py-6">
          <h1 className="text-xl font-semibold mb-2">Ajustes del restaurante</h1>

          <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4">
            Aquí podrás configurar los datos del restaurante, horarios, menú y
            otros ajustes. De momento solo hemos activado el botón para añadir
            nuevos restaurantes al grupo.
          </p>

          {isOwnerLike ? (
            <div className="space-y-3">
              <p className="text-sm text-zinc-600 dark:text-zinc-400">
                Este tenant está preparado para trabajar con varios
                restaurantes. Si quieres añadir uno nuevo al grupo, usa este
                botón:
              </p>

              <a
                href={onboardingUrl}
                target="_blank"
                rel="noreferrer"
                className="
                  inline-flex items-center gap-2
                  px-4 py-2 rounded-xl text-sm font-medium
                  border border-indigo-400/60
                  bg-indigo-500/10 hover:bg-indigo-500/20
                  text-indigo-100
                  transition-colors
                "
              >
                <span>+ Añadir restaurante</span>
                <span className="text-[11px] opacity-80">
                  (se abre en una nueva pestaña)
                </span>
              </a>
            </div>
          ) : (
            <p className="text-sm text-zinc-600 dark:text-zinc-400">
              Solo los administradores del grupo pueden añadir nuevos
              restaurantes. Si necesitas uno, contacta con el responsable de tu
              cuenta.
            </p>
          )}
        </div>
      </div>
    </DashboardShell>
  );
}