"use client";

import { ThemeToggle } from "./theme-toggle";
import { Home, Users, BarChart3, Settings } from "lucide-react";

type Item = { href: string; label: string; icon: JSX.Element };

const nav: Item[] = [
  { href: "/", label: "Reservas", icon: <Home className="w-4 h-4" /> },
  { href: "#", label: "Clientes", icon: <Users className="w-4 h-4" /> },
  { href: "#", label: "Analytics", icon: <BarChart3 className="w-4 h-4" /> },
  { href: "#", label: "Ajustes", icon: <Settings className="w-4 h-4" /> },
];

export default function DashboardShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen grid grid-cols-1 md:grid-cols-[260px_1fr] bg-white dark:bg-[#0b0b0d] text-zinc-900 dark:text-zinc-100">
      {/* Sidebar */}
{/* Sidebar */}
        <aside
        className="
            flex flex-col gap-4 
            bg-[#18191c] 
            text-zinc-300 
            border-r border-zinc-800/60
            shadow-[inset_-1px_0_0_rgba(255,255,255,0.05),0_0_30px_-15px_rgba(0,0,0,0.8)]
        "
        >
        <div className="p-4 text-lg font-semibold tracking-tight text-white">Servana</div>

        <nav className="px-2 space-y-1">
            {nav.map((n) => (
            <a
                key={n.label}
                href={n.href}
                className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium hover:bg-zinc-700/40 transition-colors data-[active=true]:bg-zinc-700/60 data-[active=true]:text-white"
                data-active={n.href === '/' ? 'true' : 'false'}
            >
                {n.icon}
                <span>{n.label}</span>
            </a>
            ))}
        </nav>

        <div className="mt-auto p-4 text-xs text-zinc-500">
            <div className="rounded-xl p-3 bg-zinc-700/30 text-zinc-300">
            ¿App móvil? Próximamente.
            </div>
        </div>
        </aside>
      {/* Main */}
      <div className="flex flex-col">
        {/* Topbar */}
        <header className="sticky top-0 z-40 border-b border-zinc-200/30 dark:border-zinc-800/60 backdrop-blur-xl bg-white/70 dark:bg-[#0b0b0d]/70">
          <div className="max-w-6xl mx-auto px-4 h-14 flex items-center gap-3">
            <div className="font-semibold tracking-tight text-lg">Reservas</div>
            <div className="ml-auto flex items-center gap-2">
              <input
                placeholder="Buscar (⌘K)…"
                className="h-9 w-56 md:w-72 rounded-lg border border-zinc-300/60 dark:border-zinc-700/60 bg-white/80 dark:bg-zinc-900/60 px-3 text-sm focus:ring-2 focus:ring-indigo-400/40 outline-none"
              />
              <ThemeToggle />
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="max-w-6xl mx-auto w-full p-4 md:p-6">{children}</main>
      </div>
    </div>
  );
}
