import { Suspense } from "react";
import { ReservationsView } from "./reservations-view";
import DashboardShell from "./dashboard-shell";

export default function Page() {
  const businessId = process.env.NEXT_PUBLIC_DEMO_BUSINESS_ID ?? "";

  return (
    <DashboardShell>
      <section className="rounded-2xl border border-zinc-200/50 dark:border-zinc-700/50 bg-white/70 dark:bg-[#121317]/90 overflow-hidden">
        <div className="px-4 py-3 border-b flex items-center gap-4">
          <div className="text-sm text-zinc-500">
            Pendientes <b className="text-zinc-900 dark:text-zinc-100">·</b> Confirmadas <b className="text-zinc-900 dark:text-zinc-100">·</b> Canceladas
          </div>
        </div>
        <div className="p-2 md:p-4">
          <Suspense fallback={<div className="h-[420px] rounded-xl border bg-white/60 dark:bg-zinc-900/60" />}>
            <ReservationsView businessId={businessId} defaultTz="Europe/Zurich" />
          </Suspense>
        </div>
      </section>
    </DashboardShell>
  );
}
