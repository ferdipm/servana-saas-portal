"use server";
import { supabaseServer } from "@/lib/supabaseServer";

export type Reservation = {
  id: string;
  phone: string | null;
  name: string;
  source: string | null;
  created_at: string;
  status: string;
  business_id: string | null;
  tz: string | null;
  chat_id: string | null;
  locator: string | null;
  party_size: number | null;
  datetime_utc: string;
  notes: string | null;
  tenant_id: string | null;
  reminder_sent: boolean | null;
};

export async function getReservations(opts: {
  businessId: string;
  q?: string;
  status?: string;
  from?: string;
  to?: string;
  limit?: number;
  cursorCreatedAt?: string | null;
}) {
  const { businessId, q, status, from, to, limit = 50 } = opts;
  const supabase = supabaseServer();

  let query = supabase
    .from("reservations")
    .select("*")
    .eq("business_id", businessId)
    .order("datetime_utc", { ascending: false })
    .limit(limit);

  if (status && status !== "all") query = query.eq("status", status);
  if (from) query = query.gte("datetime_utc", from);
  if (to) query = query.lte("datetime_utc", to);
  if (q && q.trim()) {
    query = query.or(
      `name.ilike.%${q}%,phone.ilike.%${q}%,notes.ilike.%${q}%,locator.ilike.%${q}%`
    );
  }

  const { data, error } = await query;
  if (error) throw new Error(error.message);
  const rows = (data as Reservation[]) ?? [];
  const nextCursor =
    rows.length === limit ? rows[rows.length - 1]?.created_at ?? null : null;

  return { data: rows, nextCursor };
}
