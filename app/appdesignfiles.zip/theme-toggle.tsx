"use client";

export function ThemeToggle() {
  return (
    <button
      aria-label="Cambiar tema"
      onClick={() => {
        const root = document.documentElement;
        const isDark = root.classList.toggle("dark");
        localStorage.setItem("theme", isDark ? "dark" : "light");
      }}
      className="h-9 px-3 rounded-lg border bg-white/70 dark:bg-zinc-800/60 hover:bg-white dark:hover:bg-zinc-800"
      title="Tema claro/oscuro"
    >
      🌙/☀️
    </button>
  );
}
