import "./globals.css";

export const metadata = {
  title: "Servana • Reservas",
  description: "Portal de reservas",
};

const themeInit = `
try {
  const t = localStorage.getItem('theme');
  if (t === 'dark' || (!t && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    document.documentElement.classList.add('dark');
  } else {
    document.documentElement.classList.remove('dark');
  }
} catch {}
`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeInit }} />
      </head>
      <body className="min-h-screen bg-[#0b0b0d] text-zinc-100 dark:bg-[#0b0b0d] dark:text-zinc-100 bg-white text-zinc-900">
        {children}
      </body>
    </html>
  );
}
