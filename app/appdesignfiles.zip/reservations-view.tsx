"use client";

import { useEffect, useRef, useState } from "react";
import { getReservations, Reservation } from "./actions";
import { useVirtualizer } from "@tanstack/react-virtual";

type Props = {
  businessId: string;
  defaultTz?: string;
};

export function ReservationsView({ businessId, defaultTz = "Europe/Zurich" }: Props) {
  // Filtros / estado UI
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("all");
  const [from, setFrom] = useState<string>("");
  const [to, setTo] = useState<string>("");

  const [rows, setRows] = useState<Reservation[]>([]);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [dense, setDense] = useState(false);

  async function load(initial = false) {
    if (loading) return;
    setLoading(true);
    try {
      const res = await getReservations({
        businessId,
        q,
        status,
        from,
        to,
        limit: 50,
        cursorCreatedAt: initial ? null : nextCursor,
      });
      setRows(prev => (initial ? res.data : [...prev, ...res.data]));
      setNextCursor(res.nextCursor);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [businessId, q, status, from, to]);

  // Lista virtualizada
  const parentRef = useRef<HTMLDivElement | null>(null);
  const rowVirtualizer = useVirtualizer({
    count: rows.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => (dense ? 76 : 92),
    overscan: 8,
  });

  // Infinite scroll
  useEffect(() => {
    const el = parentRef.current;
    if (!el) return;
    function onScroll() {
      const nearBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - 300;
      if (nearBottom && nextCursor && !loading) load(false);
    }
    el.addEventListener("scroll", onScroll);
    return () => el.removeEventListener("scroll", onScroll);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nextCursor, loading]);

return (
  // 🔲 Marco único y fino (ya no “card” doble ni marcos internos)
  <div className="rounded-2xl border border-zinc-200/50 dark:border-zinc-800/50 overflow-hidden">
    {/* Toolbar compacta (sin marcos adicionales) */}
    <div className="px-3 md:px-4 py-3 bg-white/70 dark:bg-[#121317]/85 backdrop-blur-sm">
      <div className="flex flex-col md:flex-row gap-2 md:items-center md:justify-between">
        <div className="flex items-center gap-2 flex-1">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar por nombre, teléfono, localizador o notas…"
            className="h-9 w-full md:w-80 rounded-lg border border-zinc-300/60 dark:border-zinc-700/60 bg-white/80 dark:bg-zinc-900/60 px-3 text-sm focus:ring-2 focus:ring-indigo-400/30 outline-none"
          />
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="h-9 rounded-lg border border-zinc-300/60 dark:border-zinc-700/60 bg-white/80 dark:bg-zinc-900/60 px-2 text-sm outline-none"
            title="Estado"
          >
            <option value="all">Todos</option>
            <option value="pending">Pendiente</option>
            <option value="confirmed">Confirmada</option>
            <option value="seated">Sentado</option>
            <option value="cancelled">Cancelada</option>
          </select>
        </div>

        <div className="flex gap-2">
          <input
            type="datetime-local"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
            className="h-9 rounded-lg border border-zinc-300/60 dark:border-zinc-700/60 bg-white/80 dark:bg-zinc-900/60 px-2 text-sm"
            title="Desde"
          />
          <input
            type="datetime-local"
            value={to}
            onChange={(e) => setTo(e.target.value)}
            className="h-9 rounded-lg border border-zinc-300/60 dark:border-zinc-700/60 bg-white/80 dark:bg-zinc-900/60 px-2 text-sm"
            title="Hasta"
          />
          <button
            onClick={() => { setQ(""); setStatus("all"); setFrom(""); setTo(""); }}
            className="h-9 px-3 rounded-lg border border-zinc-300/60 dark:border-zinc-700/60 bg-white/80 dark:bg-zinc-900/60 text-sm hover:bg-white dark:hover:bg-zinc-800"
          >
            Reset
          </button>
          <button
            onClick={() => setDense(d => !d)}
            className="h-9 px-3 rounded-lg border border-zinc-300/60 dark:border-zinc-700/60 bg-white/80 dark:bg-zinc-900/60 text-sm hover:bg-white dark:hover:bg-zinc-800"
          >
            {dense ? "Normal" : "Compacto"}
          </button>
        </div>
      </div>
    </div>

    {/* Encabezado premium de columnas (gris sutil, sin bordes gruesos) */}
    <div className="px-3 md:px-4 py-2 text-[11px] uppercase tracking-wide text-zinc-500 bg-zinc-50/80 dark:bg-[#16181d]">
      <div className="grid grid-cols-[1fr_1.2fr_1fr_1fr_1fr_auto] gap-3">
        <div>Localizador</div>
        <div>Nombre</div>
        <div>Teléfono</div>
        <div>Fecha</div>
        <div>Estado</div>
        <div></div>
      </div>
    </div>

    {/* Lista virtualizada (sin marcos internos; solo separadores finos) */}
    <div ref={parentRef} className="h-[65vh] overflow-auto bg-white/60 dark:bg-[#101114]">
      <div style={{ height: `${rowVirtualizer.getTotalSize()}px`, position: "relative" }}>
        {rowVirtualizer.getVirtualItems().map(vRow => {
          const r = rows[vRow.index];
          if (!r) return null;
          return (
            <div
              key={r.id}
              className="absolute left-0 right-0"
              style={{ top: 0, transform: `translateY(${vRow.start}px)` }}
            >
              <ReservationRow r={r} defaultTz={defaultTz} dense={dense} />
            </div>
          );
        })}
      </div>

      {loading && (
        <div className="p-6 text-center text-sm text-zinc-500">Cargando…</div>
      )}
      {!loading && rows.length === 0 && (
        <div className="p-10 text-center text-zinc-500">
          <div className="text-lg font-medium mb-1">No hay reservas</div>
          <div className="text-sm">Prueba otros filtros.</div>
        </div>
      )}
    </div>
  </div>
);
}

function StatusChip({ s }: { s?: string }) {
  const map: Record<string, { dot: string; label: string; txt: string; bg: string; brd: string }> = {
    pending:   { dot: "bg-amber-400",   label: "Pendiente",  txt: "text-amber-900 dark:text-amber-200",   bg: "bg-amber-50/80 dark:bg-amber-900/20",   brd: "border-amber-200/60 dark:border-amber-800/50" },
    confirmed: { dot: "bg-emerald-400", label: "Confirmada", txt: "text-emerald-900 dark:text-emerald-200", bg: "bg-emerald-50/80 dark:bg-emerald-900/20", brd: "border-emerald-200/60 dark:border-emerald-800/50" },
    seated:    { dot: "bg-sky-400",     label: "Sentado",    txt: "text-sky-900 dark:text-sky-200",       bg: "bg-sky-50/80 dark:bg-sky-900/20",       brd: "border-sky-200/60 dark:border-sky-800/50" },
    cancelled: { dot: "bg-rose-400",    label: "Cancelada",  txt: "text-rose-900 dark:text-rose-200",     bg: "bg-rose-50/80 dark:bg-rose-900/20",     brd: "border-rose-200/60 dark:border-rose-800/50" },
  };
  const k = s ? map[s] : undefined;
  if (!k) return <span className="text-zinc-500">—</span>;

  return (
    <span className={`inline-flex items-center gap-2 h-6 px-2 rounded-full text-xs border ${k.bg} ${k.txt} ${k.brd}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${k.dot}`} />
      {k.label}
    </span>
  );
}

function Dot({ color }: { color: "amber"|"emerald"|"sky"|"rose"|"zinc" }) {
  const map = {
    amber: "bg-amber-400",
    emerald: "bg-emerald-400",
    sky: "bg-sky-400",
    rose: "bg-rose-400",
    zinc: "bg-zinc-400",
  } as const;
  return <span className={`inline-block w-2 h-2 rounded-full ${map[color]} mr-2`} />;
}

function ReservationRow({ r, defaultTz, dense }: { r: Reservation; defaultTz: string; dense: boolean }) {
  const tz = r.tz || defaultTz;
  const dtUtc = new Date(r.datetime_utc);
  const day = dtUtc.toLocaleDateString(undefined, { day: "2-digit", month: "short", timeZone: tz });
  const time = dtUtc.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", timeZone: tz });

  return (
    <div
      className={`
        px-4 ${dense ? "py-2.5" : "py-3.5"}
        text-sm transition-colors
        hover:bg-black/[.025] dark:hover:bg-white/[.035]
        border-b border-zinc-200/40 dark:border-zinc-800/40
      `}
    >
      <div className="grid grid-cols-[1fr_1.2fr_1fr_1fr_1fr_auto] gap-3 items-center">
        <div className="truncate font-medium">#{r.locator ?? r.id.slice(0,8)}</div>
        <div className="truncate">{r.name}</div>
        <div className="truncate">{r.phone ?? "—"}</div>
        <div className="truncate">{day} · {time}</div>
        <div className="truncate">
          <StatusChip s={r.status} />
        </div>
        <div className="justify-self-end">
          <button className="h-8 px-3 rounded-lg border border-zinc-300/60 dark:border-zinc-700/60 bg-white/80 dark:bg-zinc-900/60 hover:bg-white dark:hover:bg-zinc-800">
            Ver más
          </button>
        </div>
      </div>
      <div className="mt-1 text-[12px] text-zinc-500 truncate">
        {r.party_size ?? "—"} comensal{(r.party_size ?? 0) > 1 ? "es" : ""} · {r.source ?? "—"} · {r.notes ?? "Sin notas"}
      </div>
    </div>
  );
}

function shortId(id: string) {
  return id.slice(0, 4) + "…" + id.slice(-4);
}
